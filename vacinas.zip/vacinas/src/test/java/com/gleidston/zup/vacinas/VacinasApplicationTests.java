package com.gleidston.zup.vacinas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VacinasApplicationTests {

	@Test
	void contextLoads() {
	}

}

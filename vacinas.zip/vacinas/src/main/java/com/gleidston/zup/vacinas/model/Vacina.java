package com.gleidston.zup.vacinas.model;

public class Vacina {
}
